from random import randint
import csv 

class MotATrouver:
    def __init__(self,TxtFile):
        # Description :
        # la méthode doit contenir :
        #     - l'ouverture du fichier texte contant les mots
        #     - une sélection aléatoire du mot parmi tous ceux contenues dans le fichier
        #     - tout élément que vous jugerai necessaire ou bon fonctionnement de votre objet
        
        # la variable d'entrée :
        #     - 'TxtFile' : est le nom du fichier qui contient les mots il est envoyer à la fonction __init__ à la création
        #       de l'instance de l'objet
        
        # Fonction à compléter ici :
        
        
        # j'initialise mes variable 
        self.ListeMOTS=[]
        self.Mots = []
        self.__Mot = ''
        
        self.MotVisible = []
        # j'ouvre le fichier grace a la variable TxtFile
        with open(TxtFile,'r') as File  :
                reader = csv.reader(File,delimiter=';')
                for ligne in reader:
                    self.ListeMOTS.append(ligne)
        #Je mets dans ma liste Mots , un mot aleatoire
        self.Mots.append(self.ListeMOTS[randint(0,len(self.ListeMOTS))])
        
        self.__Mot = self.Mots[0][0]
        
        self.Mots= list(self.__Mot.strip())
        # Je creer la liste avec des tirets celle qui sera afficher a l'utilisateur 
        for I in range(len(self.Mots)):
            self.MotVisible.append('-')
        self.TailleListe = len(self.Mots)
        
        
        
        
            

        print('Le mot que vous devez trouver contient:',len(self.Mots),'lettres')
        
    
    def TestLettre(self,Lettre):
        # Description :
        # La méthode doit contenir :
        #     - un test permettant de déterminer si la lettre proposée par le joueur se trouve dans le mot à trouver
        #     - créer une variable qui représente le mot à touver avec des tiret '-' pour les lettres qui n'ont pas
        #       encore été trouvé et une lettre lorsque celle ci à été découvert, lors de ce test ou précédement
        
        # La variable d'entrée :
        #     - 'Lettre' : est la lettre proposé par le joueur
        
        # La variable de sortie:
        #     - 'LettreTrouver' : est une varaible booléenne indiquant si la lettre se trouve dans le mot à trouvé
        #     - 'self.MotVisible' : est une variable représentant le mot à chercher visible par le joueur. Elle contient
        #       le symbole '-' pour chaque lettre au départ.
        
        # Fonction à compléter ici :
        
        # je cherche dans ma liste de lettre du mot si la lettre que l'utilisateur a mis est dans le mot
        LettreTrouver = False
        for i in range(len(self.Mots)):
            if self.Mots[i]==Lettre:
                self.MotVisible[i]=Lettre
                
                LettreTrouver = True
        print(self.MotVisible)
                
        return LettreTrouver
    #J'appelle ma classe avec comme paramettre le nom du fichier contenant tous les mots 
Pendu = MotATrouver('ListeMots.txt')

Essais = 0


Victoire = False

# Si la variable Victoire est pas True alors ....    
while not Victoire  :
    Joueur = input('entrez une lettre: \n')
    #je regarde si la reponse de ma classe est False , donc que ma lettre n'est pas dans le mot 
    if Pendu.TestLettre(Joueur) == False :
        
        Essais += 1
        
        
        print("Louper vous etes a l'essais n°", Essais,'il vous en reste: ',10-Essais)
        if Essais == 10 : 
        
            print('Vous avez perdu', 'Le mot etait : ',Pendu.Mots)
            Victoire = True 
    else : 
        print('il vous en reste: ',10-Essais,'Essais')
    
    if '-' not in Pendu.MotVisible :
       
        print('Vous avez gagné', 'Le mot etait : ',Pendu.Mots)
        Victoire = True 
        
            
    
        
    
    
    
    
    

            
                
                
      
            
                
                
                
            
        
                
           
        
        
            
           





       
        
        
            
            
       
        
    

